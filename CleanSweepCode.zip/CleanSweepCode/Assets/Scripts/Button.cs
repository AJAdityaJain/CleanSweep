using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class Button : MonoBehaviour
{
    public Mover script;
    public bool isPressed = false;

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (!isPressed)
        {
            script.Toggle();
        }
        isPressed = true;
    }
    private void OnCollisionExit2D(Collision2D collision)
    {
        isPressed= false;
    }

}
