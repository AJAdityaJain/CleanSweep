using UnityEngine;

public class Spawner : MonoBehaviour
{
    public GameObject Prefab;
    public int delay = 1000;

    public int i = 0;

    // Update is called once per frame
    void FixedUpdate()
    {
        if( i <= 0)
        {
            GameObject t = Instantiate(Prefab);
            t.transform.position = new Vector3(-(Random.value*10)+transform.position.x,transform.position.y, transform.position.z);
            i = delay;
        }
        i--;
    }
}
