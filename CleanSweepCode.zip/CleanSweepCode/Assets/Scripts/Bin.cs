using UnityEngine;

public class Bin : MonoBehaviour
{
    public string Type;
    //Animator animator;
    public Scorer txt;

    private void Start()
    {
        //animator= GetComponent<Animator>();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Trash")
        {
            if (collision.gameObject.GetComponent<Trash>().Type == Type)
            {
                txt.Score(1);
                Destroy(collision.gameObject);
            }
        }
    }
}