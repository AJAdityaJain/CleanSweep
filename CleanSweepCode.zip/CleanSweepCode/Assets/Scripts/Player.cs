using UnityEngine;

[RequireComponent(typeof(AudioSource))]
public class Player : MonoBehaviour
{
    Rigidbody2D rb;
    Animator anim;

    public bool DoesMove = true;

    public Scorer score;
    AudioSource audioData;

    public float speed = 2.0f;
    public float rad = 0.5f;


    void Start()
    {
        audioData = GetComponent<AudioSource>();
        anim = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();
        anim.SetBool("swim", DoesMove);
        foreach(var a in GameObject.FindGameObjectsWithTag("Trash"))
        {
            Debug.Log(a.gameObject.name);
        }
        score.Score(GameObject.FindGameObjectsWithTag("Trash").Length);
    }

    // Update is called once per frame
    void Update()
    {
        if (rb.velocity.x != 0&& DoesMove)
        {
            transform.transform.localScale = new Vector3(-Mathf.Sign(rb.velocity.x), 1, 1);
        }
        if (Input.GetKeyDown(KeyCode.E)) {
            int i = 0;
            foreach (var item in GameObject.FindGameObjectsWithTag("Trash"))
            {
                if(Mathf.Abs(Vector3.Distance(item.transform.position,transform.position)) <= rad)
                {
                    Destroy(item);
                    audioData.Play();
                    score.Score(-1);
                }
                else
                {
                    i++;
                }
            }

            if(score.score == 0)
            {
                score.End();
            }
        }
        if(DoesMove)
        rb.velocity = new Vector2(Input.GetAxis("Horizontal"), Input.GetAxis("Vertical"))*speed;
    }
}
