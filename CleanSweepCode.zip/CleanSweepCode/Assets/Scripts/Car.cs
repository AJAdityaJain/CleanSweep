
using UnityEngine;
using UnityEngine.SceneManagement;

public class Car : MonoBehaviour
{
    public float Speed;
    public Rigidbody2D rb;

    Scorer score;
    // Start is called before the first frame update
    void Start()
    {
        score = GameObject.Find("scorer").GetComponent<Scorer>();
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        rb.velocity = new Vector2(-Speed, 0);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            score.End(true);
            //Destroy(collision.gameObject);
        }
    }
}
