using UnityEngine;

public class Trash : MonoBehaviour
{
    public string Type;
    public bool IsFragile;
    public bool persistent;

    int t = 600;

    private void FixedUpdate()
    {
        if (!persistent)
        {
            t--;
            if (t == 0)
            {
                Destroy(gameObject);
            }
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(IsFragile)
        {
            Destroy(gameObject);

        }
    }
}
