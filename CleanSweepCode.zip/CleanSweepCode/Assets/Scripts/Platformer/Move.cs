using UnityEngine;

namespace Game
{/*
    [RequireComponent(typeof(Controller))]*/
    public class Move : MonoBehaviour
    {
        [SerializeField, Range(0f, 10f)] private float jumpHeight = 3f;
        [SerializeField, Range(0, 5)] private int maxAirJumps = 0;
        [SerializeField, Range(0f, 5f)] private float downwardMovementMultiplier = 3f;
        [SerializeField, Range(0f, 5f)] private float upwardMovementMultiplier = 1.7f;
        [SerializeField, Range(0f, 50f)] private int Buffer = 30;
        
        [SerializeField, Range(0f, 100f)] private float maxSpeed = 4f;
        [SerializeField, Range(0f, 100f)] private float maxAcceleration = 35f;
        [SerializeField, Range(0f, 100f)] private float maxAirAcceleration = 20f;
        /*
                private Controller controller;*/

        private int jumpPhase;
        private float defaultGravityScale;

        private bool desiredJump;
        private bool onGround;
        private int jumpBuffer = 2;
        
        
        private Vector2 direction;
        private Vector2 desiredVelocity;
        private Vector2 velocity;
        private Vector2 JumpVel;
        private Rigidbody2D body;
        private Animator anim;

        private float maxSpeedChange;
        private float acceleration;

        private float friction;

        private void Awake()
        {
            body = GetComponent<Rigidbody2D>();
            anim = GetComponent<Animator>();
            defaultGravityScale = 1f;
        }

        private void Update()
        {
            direction.x = Input.GetAxisRaw("Horizontal");
            desiredVelocity = new Vector2(direction.x, 0f) * Mathf.Max(maxSpeed - friction, 0f);
            desiredJump |= Input.GetButtonDown("Jump");
        }

        private void FixedUpdate()
        {
            velocity = body.velocity;
            
            acceleration = onGround ? maxAcceleration : maxAirAcceleration;
            maxSpeedChange = acceleration * Time.deltaTime;
            velocity.x = Mathf.MoveTowards(velocity.x, desiredVelocity.x, maxSpeedChange);

            body.velocity = velocity;
            JumpVel = body.velocity;


            if (onGround)
            {
                jumpPhase = 0;
            }

            if (desiredJump)
            {
                desiredJump = false;
                JumpAction();
            }


            if (body.velocity.y > 0)
            {
                body.gravityScale = upwardMovementMultiplier;
            }
            else if (body.velocity.y < 0)
            {
                body.gravityScale = downwardMovementMultiplier;
            }
            else if (body.velocity.y == 0)
            {
                body.gravityScale = defaultGravityScale;
            }

            body.velocity = JumpVel;
            if (body.velocity.x != 0)
                transform.transform.localScale = new Vector3(-Mathf.Sign(body.velocity.x), 1, 1);
            anim.SetFloat("x", Mathf.Abs(body.velocity.x));
            anim.SetFloat("y", Mathf.Abs(body.velocity.y));
        }


        private void JumpAction()
        {
            if (onGround || jumpPhase < maxAirJumps)
            {
                jumpPhase += 1;
                float jumpSpeed = Mathf.Sqrt(-2f * Physics2D.gravity.y * jumpHeight);
                if (JumpVel.y > 0f)
                {
                    jumpSpeed = Mathf.Max(jumpSpeed - JumpVel.y, 0f);
                }
                else if (JumpVel.y < 0f)
                {
                    jumpSpeed += Mathf.Abs(body.velocity.y);
                }
                JumpVel.y += jumpSpeed;
                jumpBuffer = Buffer;
            }
            else
            {
                jumpBuffer--;
                if (jumpBuffer > 0)
                {
                    desiredJump = true;

                }
            }
        }


        private void OnCollisionExit2D(Collision2D collision)
        {
            onGround = false;
            friction = 0;
        }

        private void OnCollisionEnter2D(Collision2D collision)
        {
            EvaluateCollision(collision);
            RetrieveFriction(collision);
        }

        private void OnCollisionStay2D(Collision2D collision)
        {
            EvaluateCollision(collision);
            RetrieveFriction(collision);
        }

        private void EvaluateCollision(Collision2D collision)
        {
            for (int i = 0; i < collision.contactCount; i++)
            {
                Vector2 normal = collision.GetContact(i).normal;
                onGround |= Mathf.Abs(normal.x) < 1.0f;
            }
        }

        private void RetrieveFriction(Collision2D collision)
        {
            PhysicsMaterial2D material = collision.rigidbody.sharedMaterial;

            friction = 0;

            if (material != null)
            {
                friction = material.friction;
            }
        }


    }
}
