using UnityEngine;

public class Mover : MonoBehaviour
{
    public Transform[] Waypoints;
    public float Speed;
    public int Iter;
    public bool ShouldGo = true;
    public float Rad;

    private void Update()
    {
        if (Vector2.Distance(Waypoints[Iter].position,transform.position) < Rad && ShouldGo)
        {
            Iter++;
            Iter %= Waypoints.Length;
        }
        transform.position = Vector2.MoveTowards(transform.position, Waypoints[Iter].transform.position, Time.deltaTime * Speed);
    }

    public void Toggle()
    {
        ShouldGo = !ShouldGo;
    }
}
