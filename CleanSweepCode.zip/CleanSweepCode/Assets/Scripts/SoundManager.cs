﻿using UnityEngine;
using UnityEngine.UI;

public class SoundManager : MonoBehaviour
{
    [SerializeField]
    Slider VolumeSlider;
    [SerializeField]
    Toggle invert;
    void Start()
    {
        if (!PlayerPrefs.HasKey("musicVolume"))
        {
            PlayerPrefs.SetFloat("musicVolume", 1);
            Load();
        }
        else
            Load();
        if (!PlayerPrefs.HasKey("invert"))
        {
            PlayerPrefs.SetInt("invert", 0);
            Load();
        }
        else
            Load();
    }

    public void ClearSave()
    {
        PlayerPrefs.DeleteAll();
    }

    public void ChangeVolume()
    {
        AudioListener.volume = VolumeSlider.value;
        Save();
    }

    private void Load()
    {
        VolumeSlider.value = PlayerPrefs.GetFloat("musicVolume");
        invert.isOn = PlayerPrefs.GetInt("invert") == 1;
    }

    public  void Save()
    {
        PlayerPrefs.SetFloat("musicVolume", VolumeSlider.value);
        PlayerPrefs.SetInt("invert", invert.isOn?1:0);
    }

}