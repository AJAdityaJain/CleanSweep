using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PanelSlider : MonoBehaviour
{
    public int i = 1000;

    public RectTransform rt;

    public float c = -0.05f;

    public float M = -0.5f;

    public bool enable = true;

    private void Start()
    {
        rt = GetComponent<RectTransform>();
    }

    void FixedUpdate()
    {
        if (enable)
        {
            if (i > 0)
            {
                i--;
            }
            else
            {
                if (rt.position.x != M)
                {
                    rt.position = Vector3.MoveTowards(rt.position, new Vector3(M, rt.position.y, rt.position.z),c);
                }
            }
        }
    }
}