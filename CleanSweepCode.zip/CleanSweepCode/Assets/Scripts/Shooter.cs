using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

[RequireComponent(typeof(AudioSource))]
[RequireComponent(typeof(LineRenderer))]
public class Shooter : MonoBehaviour
{
    public List<GameObject> Instances;
    public GameObject Test;
    public Image img;
    public Scorer Score;

    AudioSource audioData;
    LineRenderer lr;

    public bool ShouldTest = false;
    public int LineSize;
    public float g = -1f;
    public float scale = 10f;
    public float maxVelocity = 30;

    Vector3 downLoc = Vector3.zero;
    bool isDown = false;

    public List<T> Randomize<T>(List<T> list)
    {
        List<T> randomizedList = new List<T>();
        System.Random rnd = new ();
        while (list.Count > 0)
        {
            int index = rnd.Next(0, list.Count); //pick a random item from the master list
            randomizedList.Add(list[index]); //place it at the end of the randomized list
            list.RemoveAt(index);
        }
        return randomizedList;
    }

    private void Start()
    {
        Instances = Randomize(Instances);
        audioData = GetComponent<AudioSource>();
        lr = GetComponent<LineRenderer>();
        img.sprite = Instances[0].GetComponent<SpriteRenderer>().sprite;
    }

    void Update()
    {
        if (Input.GetKeyUp(KeyCode.Escape))
        {
            SceneManager.LoadScene("LevelSelector");
        }
        if (Input.GetKeyUp(KeyCode.T))
        {
            ShouldTest = !ShouldTest;
            if (ShouldTest)
            {
                img.sprite = Test.GetComponent<SpriteRenderer>().sprite;
            }
            else
            {
                img.sprite = Instances[0].GetComponent<SpriteRenderer>().sprite;
            }
        }

        if (isDown)
        {
            Vector2 v = (downLoc - Input.mousePosition) / scale;
            if (v.magnitude > maxVelocity)
            {
                v = v.normalized * maxVelocity;
            }
            lr.positionCount = LineSize;
            int s = (2 * PlayerPrefs.GetInt("invert")) - 1;

            for (int i = 0; i < LineSize; i++)
            {
                float x = transform.position.x + (v.x * i*s) / (g * Physics.gravity.y);
                float y = transform.position.y + ((v.y * i*s) + (0.5f * g * i * i)) / (g * Physics.gravity.y);
                lr.SetPosition(i, new Vector3(x, y, 0));
            }
        }
        else
        {
            lr.positionCount = 0;
        }
        if (Input.GetMouseButtonDown(0) && !isDown)
        {
            isDown = true;
            downLoc = Input.mousePosition;
        }

        if (Input.GetMouseButtonUp(0) && isDown)
        {
            isDown = false;
            var vel = (downLoc - Input.mousePosition) / scale;

            if (Instances.Count > 0)
            {
                if (vel.magnitude > 4)
                {
                    GameObject go;
                    audioData.Play(0);
                    if (ShouldTest)
                    {
                        go = Instantiate(Test);
                    }
                    else
                    {
                        go = Instantiate(Instances.ElementAt(0));
                        Instances.RemoveAt(0);
                    }

                    go.transform.position = gameObject.transform.position;
                    Rigidbody2D rb = go.GetComponent<Rigidbody2D>();
                    rb.velocity = vel;
                    if (rb.velocity.magnitude > maxVelocity)
                    {
                        rb.velocity = rb.velocity.normalized * maxVelocity;
                    }
                    rb.velocity *= (2 * PlayerPrefs.GetInt("invert"))-1;

                    //temp
                    if (ShouldTest || Instances.Count == 0)
                    {
                        img.sprite = Test.GetComponent<SpriteRenderer>().sprite;
                    }
                    else
                    {
                        img.sprite = Instances[0].GetComponent<SpriteRenderer>().sprite;
                    }
                }
            }
        }
        if (Instances.Count == 0) 
            Score.End();
    }
}