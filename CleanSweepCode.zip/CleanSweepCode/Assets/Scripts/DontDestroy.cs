using UnityEngine;

public class DontDestroy : MonoBehaviour
{
    public static DontDestroy instance = null;


    private void Awake()
    {
        if (instance == null)
        {
            GetComponent<AudioSource>().Play();
            instance = this;
            DontDestroyOnLoad(transform.gameObject);
        }
        else
        {
            Destroy(base.gameObject);
        }
    }
}