using UnityEngine;
using UnityEngine.SceneManagement;

public class Scene : MonoBehaviour
{
    void Update()
    {
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            int t = SceneManager.GetActiveScene().buildIndex - 1;
            Debug.Log(t);
            if (t >= 0)
                SceneManager.LoadScene(t);
            
        }
        if (Input.GetKey(KeyCode.RightArrow))
        {
            int t = SceneManager.GetActiveScene().buildIndex + 1;
            Debug.Log(t);
            if (t < 2)
                SceneManager.LoadScene(t);
        }

    }
}
