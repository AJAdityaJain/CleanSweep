using UnityEngine;
using UnityEngine.SceneManagement;

public class Navigator : MonoBehaviour
{
    //nono
    private void FixedUpdate()
    {
        if (Input.GetKeyUp(KeyCode.Escape))
        {
            if (SceneManager.GetActiveScene().name == "LevelSelector")
            {
                Goto("MainMenu");
            }
            else
            {
                Goto("LevelSelector");
            }
        }
    }
    public void Goto(string str)
    {
        SceneManager.LoadScene(str);
    }

    public void End()
    {
        Application.Quit();
    }
}
