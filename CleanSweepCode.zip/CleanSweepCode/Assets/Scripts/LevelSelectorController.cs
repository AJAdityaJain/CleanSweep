using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelSelectorController : MonoBehaviour
{
    public GameObject tr;
    public void Goto(string str)
    {
        if (!PlayerPrefs.HasKey("lvl"))
        {
            PlayerPrefs.SetInt("lvl", 1);
        }
        Debug.Log(PlayerPrefs.GetInt("lvl"));
        if (int.Parse(str) <= PlayerPrefs.GetInt("lvl"))
        {
            Instantiate(tr); 
            Transform c = GameObject.Find("Canvas").transform;
            GameObject g = Instantiate(tr, c);
            g.transform.GetChild(0).GetComponent<TextMeshProUGUI>().text = "Level "+ str;

            StartCoroutine(Go(str));
        }
    }

    private IEnumerator Go(string str)
    {
        yield return new WaitForSeconds(1.5f);
        SceneManager.LoadScene("lvl " + str);
    }
}