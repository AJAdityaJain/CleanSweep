using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;


[RequireComponent(typeof(AudioSource))]
public class Scorer : MonoBehaviour
{
    public TextMeshProUGUI txt;
    public string text;
    public GameObject Dialog;
    bool hasEnded = false;
    public int score = 0;
    public int required = 0;
    public bool more = true;
    public GameObject tmp;

    AudioSource audioData;
    AudioSource audioData2;
    public string TopText = "Score : ";

    private void Start()
    {
        Score(0);
        var a = GetComponents<AudioSource>();
        audioData = a[0];
        audioData2= a[1];
    }
    public void Score(int i)
    {
        score += i;
        txt.text = TopText + score.ToString();
    }

    public void End(bool b)
    {
        if (b == true)
        {
            if (!hasEnded)
            {
                hasEnded = true;
                audioData2.Play();
                StartCoroutine(waiter());
            }
        }
    }
    public void End()
    {
        if (!hasEnded)
        {

            if (tmp != null)
                tmp.SetActive(false);

            hasEnded = true;
            Debug.Log(score + "+" + required);
            if ((more && score > required) || (!more && score < required)) 
            {
                audioData.Play();
                StartCoroutine(waiter2());
            }
            else
            {
                audioData2.Play();
                StartCoroutine(waiter());
            }
        }

    }
    IEnumerator waiter2()
    {
        //Wait for 4 seconds
        yield return new WaitForSeconds(3.5f);
        Transform c = GameObject.Find("Canvas").transform;
        GameObject g = Instantiate(Dialog, c);
        g.transform.GetChild(0).GetChild(0).GetComponent<TextAnim>().stringArray = new string[] { text };

    }
    IEnumerator waiter()
    {
        yield return new WaitForSeconds(2.5f);

        SceneManager.LoadScene("FailScene");
    }
}